"""
Main entry for AmpHGT, Train, Fine-Tune, Inference in one go.
"""

import os
import mlflow
import torch
import torch.nn as nn
import torch.optim as optim

from utils.read_params import lcfig, Cfig
from utils.data import make_loaders
from utils.MaskMethod import MaskGraph
from utils.std_logger import initialize_logger, info

from trainers.pretrain_trainer import Masking_Trainer

from model.PharmHGT import PharmHGT
from seed_device import setup_seed_reproducibility

@lcfig(config_path = 'configs/pretrain.yaml', output_dir = "out_pretrain")
def pretrain_main(cfg: Cfig):
    """
    Main function to pretrain the model.
    """
    ensure_dir_exists(cfg.logger.log_dir)

    initialize_logger(cfg.logger.log_dir)

    # Initialize the random seed and device configuration for reproducibility
    devices = setup_seed_reproducibility(cfg.train.seed, cfg.train.cuda_deterministic)

    # Set up MLflow tracking if enabled
    if cfg.logger.log:
        info("Setting up MLflow tracking...")
        mlflow.set_tracking_uri(cfg.logger.tracking_uri)
        mlflow.set_experiment(cfg.logger.mlflow_exp_name)

    devices = devices[0]

    info("Creating DataLoaders...")

    pretrain_loader, vocab_dict = make_loaders(
        cfg, 
        batch_size=cfg.train.batch_size,
        mask_graph=MaskGraph(
            num_atom_type=119,
            num_edge_type=5,
            mask_edge=cfg.train.mask_edge,
            mask_atom=cfg.train.mask_atom,
            mask_fragment=cfg.train.mask_fragment,
            mask_edge_r=cfg.train.mask_edge_r,
            mask_atom_r=cfg.train.mask_atom_r,
            mask_fragment_r=cfg.train.mask_fragment_r
            )
        )

    info("Setting up model...")
    model = PharmHGT(
        cfg.train.hid_dim, 
        cfg.train.act, 
        cfg.train.num_layer,
        cfg.train.atom_dim, 
        cfg.train.bond_dim,
        cfg.train.pharm_dim, 
        cfg.train.reac_dim).to(devices)
    
    info("Setting up linear prediction layers...")
    linear_pred_atoms = torch.nn.Linear(cfg.train.hid_dim, 119).to(devices)
    # check if hid_dim at least >= vocab size
    if cfg.train.hid_dim < len(vocab_dict):
        info("Warning: hid_dim is less than vocab size. This may lead to underfitting.")
    if cfg.train.frag_method != "AdaFrag":
        linear_pred_pharms = torch.nn.Linear(cfg.train.hid_dim, len(vocab_dict)).to(devices)
    else:
        linear_pred_pharms = torch.nn.Linear(cfg.train.hid_dim, 264).to(devices)
    linear_pred_bonds = torch.nn.Linear(cfg.train.hid_dim, 4).to(devices)

    model_list = [
        model, linear_pred_atoms, linear_pred_pharms, linear_pred_bonds
    ]

    info("Setting up optimizers...")

    optimizer_model = optim.Adam(model.parameters(),
                                 lr=cfg.train.lr,
                                 weight_decay=cfg.train.decay)
    optimizer_linear_pred_atoms = optim.Adam(linear_pred_atoms.parameters(),
                                             lr=cfg.train.lr,
                                             weight_decay=cfg.train.decay)
    optimizer_linear_pred_pharms = optim.Adam(linear_pred_pharms.parameters(),
                                              lr=cfg.train.lr,
                                              weight_decay=cfg.train.decay)
    optimizer_linear_pred_bonds = optim.Adam(linear_pred_bonds.parameters(),
                                             lr=cfg.train.lr,
                                             weight_decay=cfg.train.decay)
    optimizer_list = [
        optimizer_model, 
        optimizer_linear_pred_atoms,
        optimizer_linear_pred_pharms, 
        optimizer_linear_pred_bonds
    ]

    criterion = nn.CrossEntropyLoss()

    with mlflow.start_run():
        info("Logging hyper-parameters...")
        # log hyper-parameters
        for p, v in cfg.train.items():
            mlflow.log_param(p, v)

    info("Initializing trainer...")
    trainer = Masking_Trainer(cfg=cfg,
                              global_rank=0,
                              world_size=0,
                              model_list=model_list,
                              dataloaders=pretrain_loader,
                              criterion=criterion,
                              optimizer_list=optimizer_list,
                              device=devices,
                              output_dir=cfg.logger.log_dir)
    
    info("Starting training...")
    trainer.run()

    info("finished training......")

def ensure_dir_exists(path):
    if not os.path.exists(path):
        info(f"Creating: {path}")
        os.makedirs(path)

if __name__ == '__main__':
    pretrain_main()