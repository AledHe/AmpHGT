import torch
import torch.nn as nn
import torch.nn.functional as F
import dgl
import dgl.function as fn
from dgl.nn.pytorch import GATConv, HeteroGraphConv

class Attention(nn.Module):
    def __init__(self, in_dim, out_dim, num_heads, dropout=0.1):
        super(Attention, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.num_heads = num_heads
        self.d_k = out_dim // num_heads

        self.W_q = nn.Linear(in_dim, out_dim)
        self.W_k = nn.Linear(in_dim, out_dim)
        self.W_v = nn.Linear(in_dim, out_dim)
        self.W_o = nn.Linear(out_dim, out_dim)

        self.edge_proj = nn.Linear(in_dim, out_dim)
        
        self.attn_dropout = nn.Dropout(dropout)
        self.proj_dropout = nn.Dropout(dropout)
        
        self.layer_norm = nn.LayerNorm(out_dim)
        self.ffn = nn.Sequential(
            nn.Linear(out_dim, out_dim * 4),
            nn.ReLU(),
            nn.Linear(out_dim * 4, out_dim),
            nn.Dropout(dropout)
        )

    def edge_attention(self, edges):
        # compute edge attention
        edge_h = self.edge_proj(edges.data['h'])
        return {'e': edge_h}
    
    def message_func(self, edges):
        # message prep
        q = self.W_q(edges.dst['h']).view(-1, self.num_heads, self.d_k)
        k = self.W_k(edges.src['h']).view(-1, self.num_heads, self.d_k)
        v = self.W_v(edges.src['h']).view(-1, self.num_heads, self.d_k)
        e = edges.data['e'].view(-1, self.num_heads, self.d_k)

        # compute attention score
        attn = torch.einsum('nhd,nhd->nh', q, k) / torch.sqrt(torch.tensor(self.d_k, dtype=torch.float32))
        attn = attn + torch.einsum('nhd,nhd->nh', q, e) / torch.sqrt(torch.tensor(self.d_k, dtype=torch.float32))
        
        return {'attn': attn, 'v': v}
    
    def reduce_func(self, nodes):
        # aggregate messages
        attn = F.softmax(nodes.mailbox['attn'], dim=1)
        attn = self.attn_dropout(attn)
        h = torch.einsum('bnh,bnhd->bhd', attn, nodes.mailbox['v'])
        return {'h': h.flatten(1)}
    
    def forward(self, g, h):
        with g.local_scope():
            g.ndata['h'] = h
            g.apply_edges(self.edge_attention)
            g.update_all(self.message_func, self.reduce_func)
            h_new = g.ndata['h']

            # residual connection and layer normalization
            h_new = self.layer_norm(h + self.proj_dropout(self.W_o(h_new)))

            # feedforward network
            h_new = h_new + self.ffn(h_new)

            return h_new
        
class MVMP(nn.Module):
    def __init__(self, in_dim, out_dim, num_heads, depth, attention_layers, dropout=0.1):
        super(MVMP, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.num_heads = num_heads
        self.depth = depth
        self.attention_layers = attention_layers
        self.dropout = nn.Dropout(dropout)

        self.update_edge = nn.ModuleList([nn.Linear(out_dim, out_dim) for _ in range(depth)])
        self.update_node = nn.ModuleList([nn.Linear(3*out_dim, out_dim) for _ in range(depth)])

    def forward(self, g, h):
        for i in range(self.depth):
            # Edge update
            for etype in g.etypes:
                if g.number_of_edges(etype) > 0:
                    edge_h = g.edges[etype].data['h']
                    src_type, _, dst_type = g.to_canonical_etype(etype)
                    g.edges[etype].data['m'] = self.attention_layers[i](g[src_type, etype, dst_type], h[src_type])
                    g.edges[etype].data['h'] = F.relu(edge_h + self.update_edge[i](g.edges[etype].data['m']))
            
            # Node update
            h_new = {}
            for ntype in h:
                mailbox = []
                for etype in g.etypes:
                    if g.number_of_edges(etype) > 0:
                        src_type, _, dst_type = g.to_canonical_etype(etype)
                        if dst_type == ntype:
                            mailbox.append(g.edges[etype].data['h'])
                
                if mailbox:
                    mailbox = torch.stack(mailbox).sum(dim=0)
                    h_new[ntype] = F.relu(self.update_node[i](torch.cat([h[ntype], mailbox, g.nodes[ntype].data['f']], dim=1)))
                else:
                    h_new[ntype] = h[ntype]
            
            h = h_new
        
        return h

class HGAT(nn.Module):
    def __init__(self, hid_dim, num_heads, depth, atom_dim, bond_dim, pharm_dim, reac_dim, dropout=0.1):
        super(HGAT, self).__init__()
        self.hid_dim = hid_dim
        self.num_heads = num_heads
        self.depth = depth

        # Input projections
        self.atom_proj = nn.Linear(atom_dim, hid_dim)
        self.pharm_proj = nn.Linear(pharm_dim, hid_dim)
        self.bond_proj = nn.Linear(bond_dim, hid_dim)
        self.reac_proj = nn.Linear(reac_dim, hid_dim)

        # Multi-view mechanism
        self.views = ['atom', 'pharm', 'junction']
        self.view_projections = nn.ModuleDict({
            'atom': nn.Linear(atom_dim, hid_dim),
            'pharm': nn.Linear(pharm_dim, hid_dim),
            'junction': nn.Linear(atom_dim + pharm_dim, hid_dim)
        })

        # Suffix mechanism
        self.suffixes = ['h', 'j']

        # Attention layers
        self.attention_layers = nn.ModuleList([
            Attention(hid_dim, hid_dim, num_heads, dropout) for _ in range(depth)
        ])

        self.mvmp = MVMP(hid_dim, hid_dim, num_heads, depth, self.attention_layers, dropout)

        '''
        # GAT layers
        self.gat_layers = nn.ModuleList()
        for _ in range(depth):
            self.gat_layers.append(HeteroGraphConv({
                'b': GATConv(hid_dim, hid_dim // num_heads, num_heads, feat_drop=dropout, attn_drop=dropout),
                'r': GATConv(hid_dim, hid_dim // num_heads, num_heads, feat_drop=dropout, attn_drop=dropout),
                'j': GATConv(hid_dim, hid_dim // num_heads, num_heads, feat_drop=dropout, attn_drop=dropout),
            }, aggregate='sum'))
        '''

        # Output projections
        self.atom_out = nn.Linear(hid_dim, hid_dim)
        self.pharm_out = nn.Linear(hid_dim, hid_dim)

    def forward(self, g):
        self.init_feature(g)
        
        # Initialize features with suffixes and views
        h = {suffix: {} for suffix in self.suffixes}
        for suffix in self.suffixes:
            for view in self.views:
                h[suffix][view] = self.init_features(g, view, suffix)
        
        # Message passing with suffixes
        for i in range(self.depth):
            h_new = {suffix: {} for suffix in self.suffixes}
            for suffix in self.suffixes:
                h_new[suffix] = self.mvmp(g, h[suffix])
            h = h_new

        # Final output
        embed_f_a = h['h']['atom']
        embed_f_p = h['h']['pharm']
        embed_junc_h_a = h['j']['atom']
        embed_junc_h_p = h['j']['pharm']
        
        embed_a = torch.mean(torch.stack([embed_f_a, embed_junc_h_a], dim=1), dim=1)
        embed_p = torch.mean(torch.stack([embed_f_p, embed_junc_h_p], dim=1), dim=1)
        
        return embed_a, embed_p

    def init_feature(self, g):
        g.nodes['a'].data['f'] = F.relu(self.atom_proj(g.nodes['a'].data['f']))
        g.nodes['p'].data['f'] = F.relu(self.pharm_proj(g.nodes['p'].data['f']))
        g.edges['b'].data['x'] = F.relu(self.bond_proj(g.edges['b'].data['x']))
        if g.edges['r'].data['x'].numel():
            g.edges['r'].data['x'] = F.relu(self.reac_proj(g.edges['r'].data['x']))
        
        g.nodes['a'].data['f_junc'] = torch.cat([g.nodes['a'].data['f'], torch.zeros_like(g.nodes['p'].data['f'])], 1)
        g.nodes['p'].data['f_junc'] = torch.cat([torch.zeros_like(g.nodes['a'].data['f']), g.nodes['p'].data['f']], 1)

    def init_features(self, g, view, suffix):
        if view == 'atom':
            return F.relu(self.view_projections[view](g.nodes['a'].data[f'f_{suffix}']))
        elif view == 'pharm':
            return F.relu(self.view_projections[view](g.nodes['p'].data[f'f_{suffix}']))
        elif view == 'junction':
            return F.relu(self.view_projections[view](g.nodes['a'].data[f'f_junc_{suffix}']))