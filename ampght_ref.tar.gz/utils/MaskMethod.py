import random
import torch
import dgl

from .features import ATOM_FEATURES
from .FraSCESS.mol2heterograph_FraSCESS import onek_encoding_unk

class MaskGraph:
    def __init__(self, num_atom_type, num_edge_type, mask_edge = True, 
                 mask_atom = True, mask_fragment = True, mask_edge_r = 0.1, 
                 mask_atom_r = 0.1, mask_fragment_r = 0.1):
        """
        According to the input parameters, mask the graph by following the rules:
        (1)	Random masking: Atoms not part of the backbone chain of the peptide graph are randomly masked.
        (2)	Fragment masking: Randomly masking fragments in the peptide graph, which can include sidechain, parts of the sidechain or sections of the backbone.
        
        :param num_atom_type: Number of atom types in the graph.
        :param num_edge_type: Number of edge types in the graph.
        :param mask_edge: Whether to mask edges in the graph.
        :param mask_atom: Whether to mask atoms in the graph.
        :param mask_fragment: Whether to mask fragments in the graph.
        :param mask_atom_r: The ratio of atoms to be masked.
        :param mask_fragment_r: The ratio of fragments to be masked.

        A large portion of this code is adapted from Pepland.
        """
        self.num_atom_type = num_atom_type
        self.num_edge_type = num_edge_type
        self.mask_edge = mask_edge
        self.mask_atom = mask_atom
        self.mask_fragment = mask_fragment
        self.mask_edge_r = mask_edge_r
        self.mask_atom_r = mask_atom_r
        self.mask_fragment_r = mask_fragment_r
        
    def __call__(self, g: dgl.DGLHeteroGraph):
        if self.mask_fragment:
            num_pharms = g.number_of_nodes('p')
            
            # mask_size is at least 1.
            mask_size = max(1, int(num_pharms * self.mask_fragment_r))
            masked_pharm_indices = random.sample(range(num_pharms), mask_size)
            node_mask = torch.zeros(num_pharms, dtype=torch.bool) 
            node_mask[masked_pharm_indices] = True
            g.nodes['p'].data['mask'] = node_mask

            # apply the mask feature to masked nodes
            g.nodes['p'].data['f'][node_mask] = torch.FloatTensor(GetMaskFragmentFeats())

        if self.mask_atom:
            num_atoms = g.number_of_nodes('a')
            atom_canmask = g.nodes('a')[g.nodes['a'].data['pep']] # cannot mask the amide bond atoms.
            num_mask = len(atom_canmask)

            if num_mask > 0:
                mask_size = max(1, int(num_mask * self.mask_atom_r))
                masked_atom_indices = random.sample(atom_canmask.tolist(), mask_size)
                # print(g.nodes('a')) tensor([  0,   1,   2,   3,   4
                # print('atom_canmask:',atom_canmask) atom_canmask: tensor([  4,   5,   6,   7,  12
                # print(g.nodes['a'].data['pep']) tensor([False, False, False, False, True
            
                node_mask = torch.zeros(num_atoms, dtype=torch.bool)
                node_mask[masked_atom_indices] = True
                g.nodes['a'].data['mask'] = node_mask
                g.nodes['a'].data['f'][node_mask] = torch.FloatTensor(atom_mask_features())

        # not used.
        if self.mask_edge:
            # create mask edge labels by copying edge features of edges that are bonded to mask atoms
            connected_edge_indices = []
            # check if either of the atoms connected by an edge is in the list of masked atoms.
            for atom_idx in masked_atom_indices:
                edge1 = g.in_edges(atom_idx, form = 'eid', etype = 'b')
                for e in edge1:
                    if e not in connected_edge_indices:
                        connected_edge_indices.append(int(e.detach().cpu()))

            num_edges = g.number_of_edges('b')

            edge_mask = torch.zeros(num_edges, dtype=torch.bool) 
            edge_mask[connected_edge_indices] = True
            g.edges['b'].data['mask'] = edge_mask

            for bond_idx in connected_edge_indices:
                g.edges['b'].data['x'][bond_idx] =  torch.FloatTensor(bond_mask_features())

        return g
            
def GetMaskFragmentFeats():
    emb_0 = [0 for i in range(167)]+[1]
    emb_1 = [0 for i in range(27)]+[1]

    # result_p[pharm_id] = emb_0 + emb_1

    return emb_0+emb_1

def atom_mask_features():
    features = onek_encoding_unk(10, ATOM_FEATURES['atomic_num']) + \
           onek_encoding_unk(10, ATOM_FEATURES['degree']) + \
           onek_encoding_unk(10, ATOM_FEATURES['formal_charge']) + \
           onek_encoding_unk(10, ATOM_FEATURES['chiral_tag']) + \
           onek_encoding_unk(10, ATOM_FEATURES['num_Hs']) + \
           onek_encoding_unk(10, ATOM_FEATURES['hybridization']) + \
           [0] + \
           [0.01]  # scaled to about the same range as other features
    return features

def bond_mask_features():

    fbond = [
        0,  # bond is not None
        0,
        0,
        0,
        0,
        0,
        0
    ]
    fbond += onek_encoding_unk(6, list(range(6)))

    return fbond

def validate_feature_vectors():
    fragment_feature = GetMaskFragmentFeats()
    atom_feature = atom_mask_features()

    print(fragment_feature)
    print(atom_feature)

    assert len(fragment_feature) == 196, f"Unexpected fragment feature length: {len(fragment_feature)}"
    assert len(atom_feature) == 42, f"Unexpected atom feature length: {len(atom_feature)}"

    print("Feature vector validation passed.")

if __name__ == "__main__":
    validate_feature_vectors()